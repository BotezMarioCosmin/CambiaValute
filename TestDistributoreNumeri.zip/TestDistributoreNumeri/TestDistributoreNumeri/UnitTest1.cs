using Distributore_Numeri;
namespace TestDistributoreNumeri
{
    public class UnitTest1
    {
        Distributore d;
        [Fact]
        public void IdDiversoDaNull() // 
        {
            d = new Distributore();
            Assert.True(d.Id != null);
        }
        [Fact]
        public void DittaDiversaDaNull() // 
        {
            d = new Distributore();
            Assert.True(d.Ditta != "");
        }

        [Fact]
        public void TestClone() //non � presente metodo equals
        {
            d = new Distributore("a","b",0,1,100);
            Distributore d1 = d.Clone();
            Assert.True(d1.Equals(d));
        }

        [Fact]
        public void ConteggioMaggioreDelMassimo() // non passato
        {
            d = new Distributore("a","b",0,0,100);
            for (int i = 0; i < 100; i++)
            {
                d.PrendiBiglietto(); // prendo 100 biglietti
            }
            Assert.Throws<Exception>(() => d.PrendiBiglietto()); // verifico che mi dia eccezione se prendo il 101 biglietto
        }

        [Fact]
        public void TestReset() // passato
        {
            d = new Distributore("a", "b", 0, 80, 100);
            d.Reset();
            Assert.True(d.NumCorrente == 0);
        }

        [Fact]
        public void TestNumeroCorrente() // passato
        {
            d = new Distributore("a", "b", 0, 80, 100);
            Assert.True(d.NumeroCorrente() == 80);
        }

        [Fact]
        public void TestPrendiBiglietto() // non passato
        {
            d = new Distributore("a", "b", 0, 80, 100);
            d.PrendiBiglietto();
            Assert.True(d.NumeroCorrente() == 80+1);
        }

        [Fact]
        public void TestToString() // passato
        {
            d = new Distributore("a", "b", 0, 80, 100);
            Assert.True(d.ToString() != null);
        }

        [Fact]
        public void TestBigliettiPresi() // non passato, non avendo preso nessun biglietto, l'array di biglietti dovrebbe essere null
        {
            d = new Distributore("a", "b", 0, 80, 100);
            Assert.True(d.OttieniPresi == null);
        }

        [Fact]
        public void TestVerificaSequenza() // passato
        {
            d = new Distributore("a", "b", 0, 80, 100);
            int[] i = new int[] { 1, 2, 3 };
            Assert.False(d.VerificaSequenza(i));

        }

        [Fact]
        public void TestId() // passato
        {
            Assert.Throws<Exception>(() => d = new Distributore(null, "b", 0, 80, 100));
        }
        [Fact]
        public void TestDitta() // passato
        {
            Assert.Throws<Exception>(() => d = new Distributore("a", null, 0, 80, 100));
        }
        [Fact]
        public void VerificaNumeroPartenza() // numero di partenza deve essere maggiore di 0
        {
            Assert.Throws<Exception>(() => d = new Distributore("a", "b", -1, 80, 100));
        }

        [Fact]
        public void TestNumeroAttuale() // numero attuale non pu� essere maggiore del massimo
        {
            Assert.Throws<Exception>(() => d = new Distributore("a", "b", 0, 110, 100));
        }
        [Fact]
        public void TestNumeroMassimo() // il massimo deve essere maggiore di 0
        {
            Assert.Throws<Exception>(() => d = new Distributore("a", "b", 0, 80, -1));
        }
    }
}